#!/usr/bin/python

from pymongo import MongoClient
import tornado.web

from tornado.web import HTTPError
from tornado.httpserver import HTTPServer
from tornado.ioloop import IOLoop
from tornado.options import define, options

from basehandler import BaseHandler

from sklearn.neighbors import KNeighborsClassifier
from sklearn import svm

import pickle
from bson.binary import Binary
import json
import base64
import numpy as np
import threading
import io
import matplotlib.image as mpimg



def rgb2gray(rgb):
    return np.dot(rgb[...,:3], [0.299, 0.587, 0.114])

class PrintHandlers(BaseHandler):
    def get(self):
        '''Write out to screen the handlers used
        This is a nice debugging example!
        '''
        self.set_header("Content-Type", "application/json")
        self.write(self.application.handlers_string.replace('),','),\n'))

class UploadLabeledDatapointHandler(BaseHandler):
    
        
    def add_point(self):
        data = json.loads(self.request.body.decode("utf-8"))
        
        # converting recieved base64 data to image 
        imgdata = base64.b64decode(data['feature'])
        img = mpimg.imread(io.BytesIO(imgdata), format='JPG')

        img.resize(128,128) # resizing all images to 128, 128
        gray = rgb2gray(img)    # Converting all images to grayscale
        vals = gray.flatten()   # Linearize the images to 1-D image features
        fvals = [float(val) for val in vals]

        label = data['label']
        label = label.split()[2] # to extract the label from the text received (3rd word from text)
        print("Label = %s"%label)

        sess  = data['dsid']

        dbid = self.db.labeledinstances.insert(
            {"feature":fvals,"label":label,"dsid":sess}
            );

        self.write_json({"id":str(dbid),
            "feature":[str(len(fvals))+" Points Received",
                    "min of: " +str(min(fvals)),
                    "max of: " +str(max(fvals))],
            "label":label})
        self.finish()

    # this annotation helps us manually call the finish functions, so we call it after we are ready to write the data back to the client
    @tornado.web.asynchronous
    def post(self):
        '''Save data point and class label to database
        '''

        # spawing a new thread which calls the app_point function above
        add_thread = threading.Thread(target=self.add_point, args=())
        add_thread.start()



class RequestNewDatasetId(BaseHandler):
    def get(self):
        '''Get a new dataset ID for building a new dataset
        '''
        a = self.db.labeledinstances.find_one(sort=[("dsid", -1)])
        if a == None:
            newSessionId = 1
        else:
            newSessionId = float(a['dsid'])+1
        self.write_json({"dsid":newSessionId})

class UpdateModelForDatasetId(BaseHandler):
    

    def update(self):
        dsid = self.get_int_arg("dsid",default=0)
        neigbhor  = self.get_int_arg("knn",default=3)


        # create feature vectors from database
        f=[];
        for a in self.db.labeledinstances.find({"dsid":dsid}): 
            f.append([float(val) for val in a['feature']])

        # create label vector from database
        l=[];
        for a in self.db.labeledinstances.find({"dsid":dsid}): 
            l.append(a['label'])

        print("no of features = %s"%len(f))
        print("no of labels = %s"%len(f))
        
        # fit the model to the data
        c1 = KNeighborsClassifier(n_neighbors=neigbhor);
        c2 =  svm.SVC();
        acc = -1;
        if l:
            c1.fit(f,l) # training
            c2.fit(f,l) # training
            lstar1 = c1.predict(f)
            lstar2 = c2.predict(f)
            
            self.clf[dsid] = [c1,c2]
            
            acc1 = sum(lstar1==l)/float(len(l))
            acc2 = sum(lstar2==l)/float(len(l))

            bytes1 = pickle.dumps(c1)
            bytes2 = pickle.dumps(c2)

            self.db.models.update({"dsid":dsid},
                {  "$set": {"model1":Binary(bytes1),"model2":Binary(bytes2)}  },
                upsert=True)

        # send back the resubstitution accuracy
        # if training takes a while, we are blocking tornado!! No!!
        self.write_json({"resubAccuracy":(acc1,acc2)})
        self.finish()

    # this annotation helps us manually call the finish functions, so we call it after we are ready to write the data back to the client
    @tornado.web.asynchronous
    def get(self):
        '''Train a new model (or update) for given dataset ID
        '''

        # spawing a new thread which calls the app_point function above
        update_thread = threading.Thread(target=self.update, args=())
        update_thread.start()


class PredictOneFromDatasetId(BaseHandler):

    def predict(self):
        data = json.loads(self.request.body.decode("utf-8"))    

        imgdata = base64.b64decode(data['feature'])
        img = mpimg.imread(io.BytesIO(imgdata), format='JPG')
        img.resize(128,128) # resizing all images to 128, 128
        gray = rgb2gray(img)    # Converting all images to grayscale
        vals = gray.flatten()   # Linearize the images to 1-D image features

        fvals = [float(val) for val in vals];
        fvals = np.array(fvals).reshape(1, -1)
        dsid  = data['dsid']

        # load the model from the database (using pickle)
        # we are blocking tornado!! no!!
        if dsid not in self.clf :
            print('Loading Model From DB')
            tmp = self.db.models.find_one({"dsid":dsid})
            self.clf[dsid] = [pickle.loads(tmp['model1']), pickle.loads(tmp['model2'])]

        
        predLabel1 = self.clf[dsid][0].predict(fvals);
        predLabel2 = self.clf[dsid][1].predict(fvals);

        print("Predict 1 = %s"% predLabel1)
        print("Predict 2 = %s"% predLabel2)

        self.write_json({"prediction1":str(predLabel1),"prediction2":str(predLabel2)})
        self.finish()

    
    # this annotation helps us manually call the finish functions, so we call it after we are ready to write the data back to the client
    @tornado.web.asynchronous
    def post(self):
        '''Predict the class of a sent feature vector
        '''

        # spawing a new thread which calls the app_point function above
        predict_thread = threading.Thread(target=self.predict, args=())
        predict_thread.start()
